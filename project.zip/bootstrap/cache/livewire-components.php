<?php return array (
  'dashboard-statistics' => 'App\\Http\\Livewire\\DashboardStatistics',
  'files-viewer' => 'App\\Http\\Livewire\\FilesViewer',
);