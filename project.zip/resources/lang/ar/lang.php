<?php 


return [

	//login
	"email"=>"البريد الالكتروني",
	"password"=>"كلمة المرور",
	"remember_me"=>"تذكرني",
	"forget_your_password"=>"هل نسيت كلمة المرور ؟",
	"login"=>"تسجيل الدخول",

	// register
	"register"=>"تسجيل",
	"name"=>"الإسم",
	"confirm_password"=>"تأكيد كلمة المرور",
	"Verify Your Email Address"=>"تفعيل بريدك الإلكتروني",
	"A fresh verification link has been sent to your email address."=>"تم ارسال رابط تفعيل جديد إلى بريدك الالكتروني المسجل",
	"Before proceeding, please check your email for a verification link."=>"قبل المتابعة برجاء فحص رابط التفعيل في  البريد الخاص بك.",
	"If you did not receive the email"=>"إذا لم تتلقى بريد تفعيل",
	"click here to request another"=>"إضغط هنا لإرسال رابط آخر بديل",
	







];