<a href="{{ route('admin.categories.edit',$model->id) }}" class="btn btn-primary"><i class="fas fa-user-edit text-white"></i></a>

<!--  -->