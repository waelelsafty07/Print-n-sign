<a href="{{ route('admin.categories.subcategory.index',$model->id) }}" class="btn btn-primary" style="color:white;">Go</a>
