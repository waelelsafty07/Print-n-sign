<input type="checkbox" name="item[]" class="item_checked" value="{{$model->id}}"/>
