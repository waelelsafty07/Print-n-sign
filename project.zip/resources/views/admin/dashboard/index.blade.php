<!-- <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-xxl-2 px-2 mb-3">
	<div class="col-12 px-0 py-2 d-flex " style="background: #fff;">
		<div style="width: 80px;" class="p-2">
			<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #11233b;height: 64px;border-radius: 50%;">
				<span class="fal fa-users font-5" style="color: #fff"></span>
			</div>
		</div>
		<div style="width: calc(100% - 80px)" class="px-2 py-2">
			<h6 class="font-1">المستخدمين</h6>
			<h6 class="font-3">0</h6>
		</div>
	</div>
</div> -->
@if(auth()->check())
        @php
        if(session('seen_notifications')==null)
            session(['seen_notifications'=>0]);
        $notifications=auth()->user()->notifications()->orderBy('created_at','DESC')->limit(50)->get();
        $unreadNotifications=auth()->user()->unreadNotifications()->count();
        @endphp
    @endif
<div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-xxl-2 px-2 mb-3" style="    margin: 0 0 0 auto;">
	<div class="col-12 px-0 py-2 d-flex " style="background: #fff;">
		
		<div style="width: calc(100% - 80px)" class="px-2 py-2">
			<h6 class="font-1" style="font-weight: bold;">Notification</h6>
			@if($unreadNotifications)
				<h6 class="font-3">{{$unreadNotifications}}</h6>
			@endif
		</div>
		<div style="width: 80px;" class="p-2">
			<div class="col-12 px-0 text-center d-flex align-items-center justify-content-center" style="background: #11233b;height: 64px;border-radius: 50%;">
				<span class="fal fa-bells font-5" style="color: #fff;"></span>
			</div>
		</div>
	</div>
</div>

<livewire:dashboard-statistics />