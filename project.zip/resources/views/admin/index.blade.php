@extends('layouts.admin')
@section('content')
<div class="col-12 py-2 px-3 row">
	@include('admin.dashboard.index')
</div>
@endsection