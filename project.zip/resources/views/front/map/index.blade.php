 <!--====== Section 2 ======-->
 <div class="u-s-p-b-60">


<!--====== Section Content ======-->
<div class="section__content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="g-map">
                <iframe allowtransparency="true"
      frameborder="0"
       scrolling="no"
        style="width: 100%; height: 200px; margin-top: 10px; margin-bottom: 10px;"
        src="//www.weebly.com/weebly/apps/generateMap.php?map=google&elementid=435665951656390558&ineditor=0&control=0&width=auto&height=200px&overviewmap=0&scalecontrol=0&typecontrol=0&zoom=12&long=55.26082789999998&lat=25.1836968&domain=www&point=1&align=1&reseller=true">
    </iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!--====== End - Section Content ======-->
</div>
<!--====== End - Section 2 ======-->
<div class="u-s-p-b-60">
                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                <div class="contact-o u-h-100">
                                    <div class="contact-o__wrap">
                                        <div class="contact-o__icon"><i class="fas fa-phone-volume"></i></div>

                                        <span class="contact-o__info-text-1">LET'S HAVE A CALL</span>

                                        <span class="contact-o__info-text-2">{{$settings->phone}}</span>

                                        <span class="contact-o__info-text-2">{{$settings->phone2}}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                <div class="contact-o u-h-100">
                                    <div class="contact-o__wrap">
                                        <div class="contact-o__icon"><i class="fas fa-map-marker-alt"></i></div>

                                        <span class="contact-o__info-text-1">OUR LOCATION</span>

                                        <span class="contact-o__info-text-2">{{$settings->address}}</span>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 u-s-m-b-30">
                                <div class="contact-o u-h-100">
                                    <div class="contact-o__wrap">
                                        <div class="contact-o__icon"><i class="far fa-clock"></i></div>

                                        <span class="contact-o__info-text-1">WORK TIME</span>

                                        <span class="contact-o__info-text-2">5 Days a Week</span>

                                        <span class="contact-o__info-text-2">From 9 AM to 7 PM</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>