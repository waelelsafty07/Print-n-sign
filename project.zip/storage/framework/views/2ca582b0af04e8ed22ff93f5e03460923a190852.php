<img id="img-table"  src="<?php echo e($model->ProductImage()); ?>" style="width:150px;max-width: 100%;     margin: auto;">

<?php /**PATH /opt/lampp/htdocs/laravel/dashboard/resources/views/admin/products/img.blade.php ENDPATH**/ ?>