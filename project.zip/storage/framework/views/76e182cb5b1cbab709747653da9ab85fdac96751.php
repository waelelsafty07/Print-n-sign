<a href="<?php echo e(route('admin.categories.edit',$model->id)); ?>" class="btn btn-primary"><i class="fas fa-user-edit text-white"></i></a>

<!--  --><?php /**PATH /opt/lampp/htdocs/laravel/dashboard/resources/views/admin/categories/btn/edit.blade.php ENDPATH**/ ?>