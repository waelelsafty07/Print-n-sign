<img id="img-table"  src="<?php echo e($model->CategoryImage()); ?>" style="width:150px;max-width: 100%;     margin: auto;">

<?php /**PATH /opt/lampp/htdocs/laravel/dashboard/resources/views/admin/categories/img.blade.php ENDPATH**/ ?>