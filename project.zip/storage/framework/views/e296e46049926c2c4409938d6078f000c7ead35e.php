<a href="<?php echo e(route('admin.products.edit',$model->id)); ?>" class="btn btn-primary"><i class="fas fa-user-edit text-white"></i></a>

<!--  --><?php /**PATH /opt/lampp/htdocs/laravel/dashboard/resources/views/admin/products/btn/edit.blade.php ENDPATH**/ ?>